package com.example.tipi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
